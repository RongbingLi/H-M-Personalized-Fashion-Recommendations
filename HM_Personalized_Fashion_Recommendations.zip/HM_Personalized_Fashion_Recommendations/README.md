# Project in Dat500
## Recommndation system based on categorical and numerical data

> #### setup: text file on how to setup a cluster of one namenode and three datanodes
> #### preprocessing: preprocessing using python in multiple frameworks
> #### RandomForest and MultinomialNB: TBD
> #### Dataset are in [Preprocessing](https://github.com/Tsegazab-Tesfay/DS/tree/main/preprocessing)
