from mrjob.job import MRJob
from mrjob.step import MRStep
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import string

class prod_reccomendation(MRJob):

    def steps(self):
        return [
            MRStep(mapper= self.mapper_get_articles_feature,
                   combiner= self.mapper_articles,
                   reducer=self.reducer_articles)
             ]


    #sumation of each article
    def mapper_get_articles_feature(self, _, line):

        articles_part = ['article_id','prod_name','product_type_name','product_group_name','graphical_appearance_name',
                'colour_group_name','perceived_colour_value_name','perceived_colour_master_name','department_name',
                'index_name','index_group_name','section_name','garment_group_name','detail_desc']

        cols = line.split(',')
        # drop index
        cols = cols[1:]
        article_id = cols[0]
        prod_name = cols[2]
        product_type_name = cols[4]
        product_group_name = cols[5]
        graphical_appearance_name = cols[7]
        colour_group_name = cols[9]
        perceived_colour_value_name = cols[11]
        perceived_colour_master_name = cols[13]
        department_name = cols[15]
        index_name = cols[17]
        index_group_name = cols[19]
        section_name = cols[21]
        garment_group_name = cols[23]
        detail_desc = cols[24]


        
        # droping the columns names in the output
        if articles_part[0] in cols:
              pass
        else:
            textual = (prod_name.replace(' ', '') + product_type_name.replace(' ', '') + product_group_name.replace(' ', '')+ graphical_appearance_name.replace(' ','')+            colour_group_name.replace(' ','') + perceived_colour_value_name.replace(' ','') + perceived_colour_master_name.replace(' ','') + department_name.replace(' '            ,'')+ index_name.replace(' ','')+ index_group_name.replace(' ','')+ section_name.replace(' ','')+garment_group_name.replace(' ','')+detail_desc.replace(' ',            '') ).lower()

            yield (article_id,  textual ) , 1

    def mapper_articles(self, key, values):
        texts = []
        for k in key[1]:
            s = ''
            for c in k:
                if c not in string.punctuation:
                    if not c.isdigit():
                        s += c
                        texts.append(s)
        yield (key[0], ''.join(texts)), sum(values)

    def reducer_articles(self, key, values):
        yield key[0], key[1]


if __name__ == '__main__':
    prod_reccomendation.run()
