
# Main datasets
1. [articles.csv](https://www.kaggle.com/code/sussudharsan/h-m-similar-products-recommender-script/data)
2. [custumers.csv](https://www.kaggle.com/code/sussudharsan/h-m-similar-products-recommender-script/data?select=customers.csv)
3. [transactions.csv](https://www.kaggle.com/code/sussudharsan/h-m-similar-products-recommender-script/data?select=transactions_train.csv)
Note: In this project we used only the articles and transactions csv file

# Preprocessing
The preprocessing of articles and transactions file done separately. The main idea in preprocessing for the articles was to have all possible categorical text. While the idea behind preprocessing of transactions were to have clean numerical values to work with various algorithms.

## Additional instruction
These preprocessing are tested both locally and in hadoop
> - locally -f.example .art_mreduce.py articles.csv or  pandas_additional_preprocessing.py articles.csv) and 
> - hadoop - f.example python3 .art_mreduce.py -r hadoop hdfs:///dat500/first_10_rows_article.csv --output-dir hdfs:///dat500/test_first_10_articles_cleaned1 --no-output
#### The result can be checked 
> hadoop fs -text /dat500/test_first_10_articles_cleaned1/part* | less


