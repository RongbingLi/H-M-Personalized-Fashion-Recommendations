import pandas as pd

file_1_pre = pd.read_csv("articles.csv")

# arraning features
articles_ = file_1_pre.copy()
columns = file_1_pre.columns
key_features = []


# ALTERNATIVE 1. TO CHECK THE SIZE OF MINIMAL REPRESENTATION FOR THE PAIR
for col in columns:
  # primery key --> article_id
  if col == 'article_id':
    key_features.append(col)
  elif col == 'product_code' or col == 'prod_name':
    pro_cod, pro_name= len(articles_['product_code'].unique()), len(articles_['prod_name'].unique())
    if len(articles_['product_code'].unique()) == max(pro_cod, pro_name):
      # the products can be represented by unique prod names
      if 'prod_name' not in key_features:
        key_features.append('prod_name')
        print(articles_.dtypes['prod_name'])
      else:
        continue
  elif col == 'product_type_no' or col == 'product_type_name':
    pro_cod, pro_name= len(articles_['product_type_no'].unique()), len(articles_['product_type_name'].unique())
    if len(articles_['product_type_no'].unique()) == max(pro_cod, pro_name):
      if 'product_type_name' not in key_features:
        key_features.append('product_type_name')
      else:
        continue
  elif col == 'graphical_appearance_no' or col == 'graphical_appearance_name':
    pro_cod, pro_name= len(articles_['graphical_appearance_no'].unique()), len(articles_['graphical_appearance_name'].unique())
    if len(articles_['graphical_appearance_no'].unique()) == max(pro_cod, pro_name):
      if 'graphical_appearance_name' not in key_features:
        key_features.append('graphical_appearance_name')
      else:
        continue
  elif col == 'colour_group_code' or col == 'colour_group_name':
    pro_cod, pro_name= len(articles_['colour_group_code'].unique()), len(articles_['colour_group_name'].unique())
    if len(articles_['colour_group_code'].unique()) == max(pro_cod, pro_name):
      if 'colour_group_name' not in key_features:
        key_features.append('colour_group_name')
      else:
        continue
  elif col == 'perceived_colour_value_id' or col == 'perceived_colour_value_name':
    pro_cod, pro_name= len(articles_['perceived_colour_value_id'].unique()), len(articles_['perceived_colour_value_name'].unique())
    if len(articles_['perceived_colour_value_id'].unique()) == max(pro_cod, pro_name):
      if 'perceived_colour_value_name' not in key_features:
        key_features.append('perceived_colour_value_name')
      else:
        continue
  elif col == 'perceived_colour_master_id' or col == 'perceived_colour_master_name':
    pro_cod, pro_name= len(articles_['perceived_colour_master_id'].unique()), len(articles_['perceived_colour_master_name'].unique())
    if len(articles_['perceived_colour_master_id'].unique()) == max(pro_cod, pro_name):
      if 'perceived_colour_master_name' not in key_features:
        key_features.append('perceived_colour_master_name')
      else:
        continue
  elif col == 'department_no' or col == 'department_name':
    pro_cod, pro_name= len(articles_['department_no'].unique()), len(articles_['department_name'].unique())
    if len(articles_['department_no'].unique()) == max(pro_cod, pro_name):
      if 'department_name' not in key_features:
        key_features.append('department_name')
      else:
        continue
  elif col == 'index_code' or col == 'index_name':
    pro_cod, pro_name= len(articles_['index_code'].unique()), len(articles_['index_name'].unique())
    if len(articles_['index_code'].unique()) == max(pro_cod, pro_name):
      if 'index_name' not in key_features:
        key_features.append('index_name')
      else:
        continue
  elif col == 'index_group_no' or col == 'index_group_name':
    pro_cod, pro_name= len(articles_['index_group_no'].unique()), len(articles_['index_group_name'].unique())
    if len(articles_['index_group_no'].unique()) == max(pro_cod, pro_name):
      if 'index_group_name' not in key_features:
        key_features.append('index_group_name')
      else:
        continue
  elif col == 'section_no' or col == 'section_name':
    pro_cod, pro_name= len(articles_['section_no'].unique()), len(articles_['section_name'].unique())
    if len(articles_['section_no'].unique()) == max(pro_cod, pro_name):
      if 'section_name' not in key_features:
        key_features.append('section_name')
      else:
        continue
  elif col == 'garment_group_no' or col == 'garment_group_name':
    pro_cod, pro_name= len(articles_['garment_group_no'].unique()), len(articles_['garment_group_name'].unique())
    if len(articles_['garment_group_no'].unique()) == max(pro_cod, pro_name):
      if 'garment_group_name' not in key_features:
        key_features.append('garment_group_name')
      else:
        continue


## ALTERNATIVE 2. IF WE WERE SURE ABOUT THE SIZE OF THE PAIR AND DATATYPE
key_features_2 = []
for col in columns:
  if col.endswith('name') and col not in key_features_2:
    key_features_2.append(col)
  else:
    continue


## CONTINUE WITH ALTERNATIVE 2. - key_features_2 in creating models
print(key_features_2)
