
import numpy as np
import pandas as pd
#import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
#import matplotlib.pyplot as plt

# Didn't use - cause original string is not in use
#nlp = spacy.load("en_core_web_sm")
#stop_words_ = nlp.Defaults.stop_words

from sklearn.metrics.pairwise import cosine_similarity




file_1 = "articles.csv"
#file_2 = pd.read_csv("customers.csv")
file_3 = pd.read_csv("transactions_train.csv")
transactions = file_3[:1000]


def read_files_df(path1, n):
  articles = pd.read_csv(path1)
  articles = articles[:n]
  #customers = pd.read_csv(path2)
  #transactions = pd.read_csv(path3)

  cols_ = []
  # categorical features and their article id
  articles_part = articles[['article_id','prod_name','product_type_name','product_group_name','graphical_appearance_name','colour_group_name'
                         ,'perceived_colour_value_name','perceived_colour_master_name','department_name','index_name','index_group_name'
                         ,'section_name','garment_group_name','detail_desc']]

  for i in articles_part.columns[1:]:
    articles_part[i] = articles_part[i].str.replace(" ", "")
    cols_.append(i)
  # merging texts
  articles_part['merged'] =  articles_part[cols_].apply(lambda x: ' '.join(x.values.astype(str)), axis=1)
  final_data = articles_part[[articles_part.columns[0], articles_part.columns[-1]]]
  final_data['merged'] = final_data['merged'].fillna('')
  indices = pd.Series(final_data.index, index=final_data['article_id'].drop_duplicates())

  # vectorization
  vectorizer = TfidfVectorizer(stop_words='english')
  matr_ = vectorizer.fit_transform(final_data['merged'])

  # check the first two representation
  #check_representation = matr_.todense()
  #df = pd.DataFrame(check_representation, columns = vectorizer.get_feature_names(), index=['first', 'second'])
  #df

  # preform cosine similarity
  cosine_sim_ = cosine_similarity(matr_, matr_)

  return final_data, cosine_sim_, indices

def arranging_index(data):
  ind = [i for i in range(len(data))]
  data.set_index(pd.Series(ind), inplace=True)
  return data

n = 1000 # the number of rows to work with
final_data, cosine_sim_, indices = read_files_df(file_1, n)

def recommend(art_id, d_size):
  # d_size - the size of data to be handled
  idx = indices[art_id]
  # subtracting the proper data size to find proper result
  sim_scores = list(enumerate(cosine_sim_[abs(idx - d_size)])) # abs(idx-20000)
  sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
  sim_scores = sim_scores[:10]
  article_indices = [i[0] for i in sim_scores]
  return final_data['article_id'].iloc[article_indices]


transactions['recom'] = None
from time import time
start = time()
for i in range(len(transactions)):

  if transactions['article_id'][i] in final_data['article_id'].unique():
    rec_ = list(recommend(transactions.article_id[i], 0))
    transactions['recom'][i] = [l for l in rec_ if l != transactions['article_id'][i]]
  else:
    continue
end = time()
execution_time = end - start
print("Execution Time : ", execution_time)


transactions = transactions[['customer_id', 'article_id', 'recom']]
print(transactions.head())
