from pyspark.sql import SparkSession
from pyspark.sql.functions import min
from pyspark.sql.functions import max
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import from_unixtime
from pyspark.ml.feature import StringIndexer
from pyspark.ml import Pipeline
from pyspark.sql.functions import col
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS

from datetime import datetime
start_time = datetime.now()

spark_s = SparkSession.builder.appName('RecommendationSystem').getOrCreate()
spark = SparkSession(spark_s)

transaction = spark.read.option("header",True).csv("./transactions_train.csv", inferSchema=True)
# Cheking which columns
transaction.printSchema() #

# start and end time of the gathered data
def date_gathered(dateframe):
    date_start = dataframe.withColumn('t')# dateframe.select(min('t_dat')).first()
    date_end = dateframe.select(max('t_dat')).first()
    return date_start, date_end


# select feature, train model and return rmse, recommend items
def columnsForPrePrecessing(dataframe):

    columns = dataframe.columns
    us_col = ['customer_id', 'article_id']
    # testing first for 1000
    #dataframe = dataframe.limit(1000)


    #dataframe = dataframe.groupBy("customer_id").count().orderBy('count', ascending=False)
    #df.show(30)#checker
    dataframe = dataframe.groupby('customer_id', 'article_id').count()
    indexer = StringIndexer(inputCols =['customer_id', 'article_id'], outputCols = ['customer_id_indexed','article_id_indexed'])
    data_transformed = indexer.fit(dataframe).transform(dataframe)

    #dataframe.show(5)
    # train and test
    train, test = data_transformed.randomSplit([0.7, 0.3])
    
    # Models and evaluate rmse
    ls = ALS(maxIter=5, regParam=0.09, rank=25, userCol='customer_id_indexed',
            itemCol='article_id_indexed', ratingCol='count', coldStartStrategy='drop', nonnegative=True)

    model_1 = ls.fit(train)
    evaluate = RegressionEvaluator(metricName='rmse', labelCol='count', predictionCol='prediction')
    pred = model_1.transform(test)
    rmse_ = evaluate.evaluate(pred)
    

    print('Result of rmse: ', rmse_)
    
    # return top numUsrs -10  and recommendation for each
    given_ = model_1.recommendForAllItems(10).show(10)
    return rmse_, pred.show(10)


#Data gathering date
#print(date_gathered(transaction))

#Important data-sets
columnsForPrePrecessing(transaction) # to save all as pd dataFrame see my notebook file

